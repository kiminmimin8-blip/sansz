package com.sanz.market.commands;

import com.sanz.market.managers.TvManager;
import com.sanz.market.managers.VideoScreenManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class MarketTvCommand implements CommandExecutor {

    private final TvManager tvManager;
    private final VideoScreenManager videoScreenManager;

    public MarketTvCommand(TvManager tvManager, VideoScreenManager videoScreenManager) {
        this.tvManager = tvManager;
        this.videoScreenManager = videoScreenManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanz.market.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (args.length < 1) {
            sendUsage(sender);
            return true;
        }

        String action = args[0].toLowerCase();
        switch (action) {
            case "give":
                return give(sender, args);
            case "list":
                sender.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "== TV Terpasang ==");
                sender.sendMessage(ChatColor.GRAY + "Total: " + ChatColor.YELLOW + tvManager.getTvCount());
                return true;
            case "screen":
                return screen(sender, args);
            case "play":
                return play(sender, args);
            case "stop":
                return stop(sender, args);
            case "videos":
                List<String> videos = videoScreenManager.listVideos();
                sender.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "== Video Tersedia ==");
                sender.sendMessage(videos.isEmpty()
                        ? ChatColor.GRAY + "(kosong - taruh file .mp4 di plugins/SanzMarket/videos/)"
                        : ChatColor.YELLOW + String.join(", ", videos));
                return true;
            default:
                sendUsage(sender);
                return true;
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.RED + "Gunakan salah satu:");
        sender.sendMessage(ChatColor.GRAY + "/markettv give <player>  &7- kasih TV block (teks: saham/bola)");
        sender.sendMessage(ChatColor.GRAY + "/markettv list  &7- list TV block terpasang");
        sender.sendMessage(ChatColor.GRAY + "/markettv screen pos1|pos2  &7- pilih item frame pojok layar");
        sender.sendMessage(ChatColor.GRAY + "/markettv screen create <nama>  &7- bikin layar video dari grid item frame");
        sender.sendMessage(ChatColor.GRAY + "/markettv screen list  &7- list layar video terpasang");
        sender.sendMessage(ChatColor.GRAY + "/markettv videos  &7- list file video yang ke-upload");
        sender.sendMessage(ChatColor.GRAY + "/markettv play <layar> <video.mp4> [fps]  &7- muterin video");
        sender.sendMessage(ChatColor.GRAY + "/markettv stop <layar>  &7- stop video");
    }

    private boolean give(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player " + args[1] + " gak online.");
                return true;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            sender.sendMessage(ChatColor.RED + "Gunakan: /markettv give <player>");
            return true;
        }

        target.getInventory().addItem(tvManager.createTvItem());
        sender.sendMessage(ChatColor.GREEN + "TV berhasil diberikan ke " + target.getName() + "!");
        return true;
    }

    private boolean screen(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /markettv screen <pos1|pos2|create|list>");
            return true;
        }

        String sub = args[1].toLowerCase();
        if (sub.equals("pos1") || sub.equals("pos2")) {
            String error = videoScreenManager.setPos(player, sub.equals("pos1") ? 1 : 2);
            player.sendMessage(error == null
                    ? ChatColor.GREEN + (sub.equals("pos1") ? "Pos1" : "Pos2") + " di-set ke item frame yang kamu lihat."
                    : ChatColor.RED + error);
            return true;
        }

        if (sub.equals("list")) {
            List<String> screens = videoScreenManager.listScreens();
            sender.sendMessage(ChatColor.GRAY + "Layar video: " + ChatColor.WHITE
                    + (screens.isEmpty() ? "(belum ada)" : String.join(", ", screens)));
            return true;
        }

        if (sub.equals("create")) {
            if (args.length < 3) {
                player.sendMessage(ChatColor.RED + "Gunakan: /markettv screen create <nama>");
                return true;
            }
            String error = videoScreenManager.createScreen(player, args[2]);
            player.sendMessage(error == null
                    ? ChatColor.GREEN + "Layar '" + args[2] + "' berhasil dibuat!"
                    : ChatColor.RED + error);
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Gunakan: /markettv screen <pos1|pos2|create|list>");
        return true;
    }

    private boolean play(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /markettv play <layar> <video.mp4> [fps]");
            return true;
        }
        int fps = 8;
        if (args.length >= 4) {
            try {
                fps = Math.max(1, Math.min(20, Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "FPS harus angka.");
                return true;
            }
        }

        String error = videoScreenManager.play(args[1], args[2], fps);
        sender.sendMessage(error == null
                ? ChatColor.GREEN + "Muter '" + args[2] + "' di layar '" + args[1] + "' (" + fps + " fps)."
                : ChatColor.RED + error);
        return true;
    }

    private boolean stop(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /markettv stop <layar>");
            return true;
        }
        boolean stopped = videoScreenManager.stop(args[1]);
        sender.sendMessage(stopped
                ? ChatColor.GREEN + "Video di layar '" + args[1] + "' dihentikan."
                : ChatColor.RED + "Layar '" + args[1] + "' lagi gak muter apa-apa.");
        return true;
    }
}
