package com.sanz.market.gui;

import com.sanz.market.managers.MarketManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI beli/jual: jumlah lot bisa di-adjust pake tombol -64/-10/-1 /
 * +1/+10/+64 (gaya shop kebanyakan plugin), tengah nampilin harga
 * live, tombol konfirmasi buat eksekusi transaksi beneran.
 */
public class TradeGuiListener implements Listener {

    private static MarketManager marketManagerRef; // di-set sekali pas plugin enable

    public static void register(MarketManager marketManager) {
        marketManagerRef = marketManager;
    }

    public static void open(Player player, MarketManager marketManager, String stockName, String action) {
        TradeGuiHolder holder = new TradeGuiHolder(stockName, action);
        String title = (action.equals("buy") ? "&a&lBELI " : "&c&lJUAL ") + stockName;
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.translateAlternateColorCodes('&', title));
        holder.setInventory(inv);

        player.openInventory(inv);
        redraw(player, marketManager, holder);
    }

    private static void redraw(Player player, MarketManager marketManager, TradeGuiHolder holder) {
        Inventory inv = holder.getInventory();
        MarketManager.StockData stock = marketManager.getStock(holder.stockName);
        if (stock == null) {
            player.closeInventory();
            return;
        }

        double total = stock.price * holder.quantity;

        ItemStack border = GuiItemUtil.named(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 27; i++) inv.setItem(i, border);

        inv.setItem(10, GuiItemUtil.named(Material.RED_STAINED_GLASS_PANE, "&c-64", null));
        inv.setItem(11, GuiItemUtil.named(Material.RED_STAINED_GLASS_PANE, "&c-10", null));
        inv.setItem(12, GuiItemUtil.named(Material.RED_STAINED_GLASS_PANE, "&c-1", null));
        inv.setItem(14, GuiItemUtil.named(Material.LIME_STAINED_GLASS_PANE, "&a+1", null));
        inv.setItem(15, GuiItemUtil.named(Material.LIME_STAINED_GLASS_PANE, "&a+10", null));
        inv.setItem(16, GuiItemUtil.named(Material.LIME_STAINED_GLASS_PANE, "&a+64", null));

        if (holder.action.equals("buy")) {
            inv.setItem(13, GuiItemUtil.named(stock.icon, "&e&lJumlah: " + holder.quantity + " lot", List.of(
                    "&7Harga satuan: &e$" + String.format("%.0f", stock.price),
                    "&7Total bayar: &6$" + String.format("%.0f", total),
                    marketManager.isEconomyAvailable()
                            ? "&7Saldo kamu: &a$" + String.format("%.0f", getBalance(player, marketManager))
                            : "&c(Vault gak ke-hook, transaksi gak akan jalan)")));
            inv.setItem(22, GuiItemUtil.named(Material.EMERALD, "&a&l✔ KONFIRMASI BELI", List.of(
                    "&7Beli &e" + holder.quantity + " lot " + stock.name,
                    "&7Total: &6$" + String.format("%.0f", total))));
        } else {
            int owned = marketManager.getHolding(player.getUniqueId(), stock.name);
            inv.setItem(13, GuiItemUtil.named(stock.icon, "&e&lJumlah: " + holder.quantity + " lot", List.of(
                    "&7Harga satuan: &e$" + String.format("%.0f", stock.price),
                    "&7Total dapat: &6$" + String.format("%.0f", total),
                    "&7Kamu punya: &a" + owned + " lot")));
            inv.setItem(22, GuiItemUtil.named(Material.EMERALD, "&c&l✔ KONFIRMASI JUAL", List.of(
                    "&7Jual &e" + holder.quantity + " lot " + stock.name,
                    "&7Total: &6$" + String.format("%.0f", total))));
        }

        inv.setItem(26, GuiItemUtil.named(Material.BARRIER, "&c&lBatal", null));
    }

    private static double getBalance(Player player, MarketManager marketManager) {
        if (!marketManager.isEconomyAvailable()) return 0;
        return marketManager.getEconomy().getBalance(player);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof TradeGuiHolder holder)) return;
        event.setCancelled(true);

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;
        ItemStack clicked = event.getInventory().getItem(slot);
        if (clicked == null || clicked.getType() == Material.AIR) return;

        Player player = (Player) event.getWhoClicked();

        if (slot == 26) {
            player.closeInventory();
            return;
        }

        if (slot == 22) {
            MarketManager.TradeResult result = holder.action.equals("buy")
                    ? marketManagerRef.buy(player, holder.stockName, holder.quantity)
                    : marketManagerRef.sell(player, holder.stockName, holder.quantity);
            sendResultMessage(player, result, holder);
            player.closeInventory();
            return;
        }

        int delta = switch (slot) {
            case 10 -> -64;
            case 11 -> -10;
            case 12 -> -1;
            case 14 -> 1;
            case 15 -> 10;
            case 16 -> 64;
            default -> 0;
        };
        if (delta == 0) return;

        holder.quantity = Math.max(1, holder.quantity + delta);
        redraw(player, marketManagerRef, holder);
    }

    private void sendResultMessage(Player player, MarketManager.TradeResult result, TradeGuiHolder holder) {
        String prefix = ChatColor.translateAlternateColorCodes('&', "&8[&6Market&8]&7 ");
        String msg = switch (result) {
            case SUCCESS -> holder.action.equals("buy")
                    ? "&fBerhasil beli &e" + holder.quantity + " lot " + holder.stockName
                    : "&fBerhasil jual &e" + holder.quantity + " lot " + holder.stockName;
            case STOCK_NOT_FOUND -> "&cSaham tidak ditemukan.";
            case BELOW_MIN -> "&cTotal transaksi di bawah minimal.";
            case ABOVE_MAX -> "&cTotal transaksi melebihi maksimal per transaksi.";
            case INSUFFICIENT_BALANCE -> "&cSaldo kamu tidak cukup!";
            case INSUFFICIENT_HOLDINGS -> "&cLot yang kamu punya tidak cukup!";
            case NO_ECONOMY -> "&cVault/plugin economy belum siap, hubungi admin.";
        };
        player.sendMessage(prefix + ChatColor.translateAlternateColorCodes('&', msg));
    }
}
