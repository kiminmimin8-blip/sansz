package com.sanz.market.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Marker + state buat GUI trade (beli/jual). State (saham, aksi,
 * jumlah) nempel langsung di holder-nya, jadi otomatis hilang begitu
 * inventory-nya ditutup — gak perlu bersih-bersih map manual.
 */
public class TradeGuiHolder implements InventoryHolder {
    private Inventory inventory;
    public final String stockName;
    public final String action; // "buy" atau "sell"
    public int quantity = 1;

    public TradeGuiHolder(String stockName, String action) {
        this.stockName = stockName;
        this.action = action;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
