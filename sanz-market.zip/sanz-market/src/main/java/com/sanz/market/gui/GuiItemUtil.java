package com.sanz.market.gui;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Helper bikin ItemStack ber-nama & lore buat semua GUI market,
 * biar gak duplikat kode di tiap listener.
 */
public final class GuiItemUtil {

    private GuiItemUtil() {}

    public static ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            if (lore != null) {
                meta.setLore(lore.stream()
                        .map(s -> ChatColor.translateAlternateColorCodes('&', s))
                        .toList());
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
