package com.sanz.market.managers;

import java.util.List;
import java.util.Random;

/**
 * Simulasi pertandingan bola buat channel "Sepak Bola" di TV block.
 *
 * CATATAN: ini SIMULASI (kayak saham Nether/End/Ocean/Cave yang emang
 * fiktif dari awal), bukan data pertandingan asli dari internet. Kalau
 * ke depannya mau dihubungin ke API bola beneran (butuh API key +
 * internet access dari server), tinggal ganti isi tick() ini buat
 * fetch dari API-nya, struktur Match di bawah gak perlu berubah.
 */
public class FootballManager {

    private static final String[] TEAM_POOL = {
            "Nether United", "End FC", "Ocean Rangers", "Cave Miners",
            "Overworld City", "Bastion Warriors", "Reef Sharks", "Stronghold SC"
    };

    private final Random random = new Random();
    private Match current;

    public FootballManager() {
        startNewMatch();
    }

    private void startNewMatch() {
        String home = TEAM_POOL[random.nextInt(TEAM_POOL.length)];
        String away;
        do {
            away = TEAM_POOL[random.nextInt(TEAM_POOL.length)];
        } while (away.equals(home));

        current = new Match(home, away);
    }

    /**
     * 1 siklus simulasi (dipanggil bareng update TV, jadi berasa "live").
     * Tiap tick nambah beberapa menit + ada peluang kecil kebobolan gol.
     */
    public void tick() {
        if (current.finished) {
            startNewMatch();
            return;
        }

        current.minute += 3 + random.nextInt(4); // maju 3-6 menit tiap tick

        if (random.nextDouble() < 0.12) current.homeScore++;
        if (random.nextDouble() < 0.12) current.awayScore++;

        if (current.minute >= 90) {
            current.minute = 90;
            current.finished = true;
        }
    }

    public Match getCurrentMatch() {
        return current;
    }

    public static class Match {
        public final String homeTeam;
        public final String awayTeam;
        public int homeScore = 0;
        public int awayScore = 0;
        public int minute = 0;
        public boolean finished = false;

        public Match(String homeTeam, String awayTeam) {
            this.homeTeam = homeTeam;
            this.awayTeam = awayTeam;
        }
    }
}
