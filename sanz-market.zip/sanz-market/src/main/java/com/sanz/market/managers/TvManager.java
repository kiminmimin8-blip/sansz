package com.sanz.market.managers;

import com.sanz.market.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * TV block: register lokasi block + entity TextDisplay yang nempel di
 * atasnya. Beda dari versi Skript lama (butuh plugin DecentHolograms),
 * versi ini pakai TextDisplay bawaan Paper (Display entity vanilla
 * 1.19.4+) dengan billboard CENTER, jadi teksnya otomatis selalu
 * ngadep ke arah player ngeliat — gak perlu ngatur axis x/z manual.
 */
public class TvManager {

    private final JavaPlugin plugin;
    private final ConfigFile tvData;
    private final MarketManager marketManager;
    private final FootballManager footballManager;
    private final Material blockMaterial;
    private final NamespacedKey tvItemKey;

    private final Map<Integer, TvEntry> tvs = new LinkedHashMap<>();
    private int counter = 0;

    public TvManager(JavaPlugin plugin, ConfigFile tvData, MarketManager marketManager,
                      FootballManager footballManager, Material blockMaterial) {
        this.plugin = plugin;
        this.tvData = tvData;
        this.marketManager = marketManager;
        this.footballManager = footballManager;
        this.blockMaterial = blockMaterial;
        this.tvItemKey = new NamespacedKey(plugin, "tv_item");
        load();
    }

    public Material getBlockMaterial() {
        return blockMaterial;
    }

    /**
     * Bikin item TV yang bisa di-place jadi block TV beneran. Ditandain
     * lewat PersistentDataContainer (bukan cuma display name) biar
     * deteksinya gak gampang ke-fake pake item lain yang kebetulan
     * namanya sama.
     */
    public ItemStack createTvItem() {
        ItemStack item = new ItemStack(blockMaterial);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f&l📺 TV"));
            meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Pasang buat nonton saham, bola, dll."),
                    ChatColor.translateAlternateColorCodes('&', "&7Klik kanan buat ganti channel.")));
            meta.getPersistentDataContainer().set(tvItemKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isTvItem(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer().has(tvItemKey, PersistentDataType.BYTE);
    }

    private void load() {
        tvs.clear();
        counter = tvData.get().getInt("counter", 0);

        ConfigurationSection section = tvData.get().getConfigurationSection("tvs");
        if (section == null) return;

        for (String idStr : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(idStr);
            if (s == null) continue;

            int id = Integer.parseInt(idStr);
            String worldName = s.getString("world");
            World world = Bukkit.getWorld(worldName);
            if (world == null) continue; // world belum ke-load, skip dulu

            int x = s.getInt("x"), y = s.getInt("y"), z = s.getInt("z");
            String channel = s.getString("channel", "market");
            String uuidStr = s.getString("entity-uuid");
            UUID entityUuid = uuidStr != null ? UUID.fromString(uuidStr) : null;

            tvs.put(id, new TvEntry(id, worldName, x, y, z, channel, entityUuid));
        }
    }

    public void save() {
        tvData.get().set("tvs", null);
        tvData.get().set("counter", counter);
        for (TvEntry tv : tvs.values()) {
            String path = "tvs." + tv.id;
            tvData.get().set(path + ".world", tv.world);
            tvData.get().set(path + ".x", tv.x);
            tvData.get().set(path + ".y", tv.y);
            tvData.get().set(path + ".z", tv.z);
            tvData.get().set(path + ".channel", tv.channel);
            tvData.get().set(path + ".entity-uuid", tv.entityUuid != null ? tv.entityUuid.toString() : null);
        }
        tvData.save();
    }

    // ================= Place / remove =================

    /**
     * Register block yang baru aja di-place sebagai TV, spawn TextDisplay
     * di atasnya. HARUS dipanggil dari thread yang bener (region thread
     * pemilik block itu) — di listener biasanya udah otomatis benar
     * karena dipanggil dari dalam BlockPlaceEvent.
     */
    public int placeTv(Block block) {
        counter++;
        int id = counter;

        Location displayLoc = block.getLocation().add(0.5, 1.3, 0.5);
        TextDisplay display = block.getWorld().spawn(displayLoc, TextDisplay.class, entity -> {
            entity.setBillboard(Display.Billboard.CENTER);
            entity.setAlignment(TextDisplay.TextAlignment.CENTER);
            entity.setLineWidth(200);
            entity.setBackgroundColor(org.bukkit.Color.fromARGB(140, 0, 0, 0));
            entity.setPersistent(true);
        });

        String defaultChannel = "market";
        TvEntry entry = new TvEntry(id, block.getWorld().getName(), block.getX(), block.getY(), block.getZ(),
                defaultChannel, display.getUniqueId());
        tvs.put(id, entry);
        save();

        refreshOne(entry, display);
        return id;
    }

    /**
     * Cari TV yang match sama block ini (kalau ada). Return null kalau
     * block ini bukan TV yang keregister.
     */
    public int getTvCount() {
        return tvs.size();
    }

    public TvEntry getTvAt(Block block) {
        for (TvEntry tv : tvs.values()) {
            if (tv.world.equals(block.getWorld().getName())
                    && tv.x == block.getX() && tv.y == block.getY() && tv.z == block.getZ()) {
                return tv;
            }
        }
        return null;
    }

    public void removeTv(TvEntry entry) {
        Entity display = findDisplayEntity(entry);
        if (display != null) display.remove();
        tvs.remove(entry.id);
        save();
    }

    public void setChannel(TvEntry entry, String channel) {
        entry.channel = channel;
        save();
        Entity display = findDisplayEntity(entry);
        if (display instanceof TextDisplay textDisplay) {
            refreshOne(entry, textDisplay);
        }
    }

    private Entity findDisplayEntity(TvEntry entry) {
        if (entry.entityUuid == null) return null;
        return Bukkit.getEntity(entry.entityUuid);
    }

    // ================= Content refresh =================

    /**
     * Refresh semua TV yang lagi ke-load world-nya. Tiap TV di-refresh
     * lewat region scheduler lokasinya sendiri (aman buat Folia, karena
     * tiap TV bisa aja ada di region/world yang beda-beda).
     */
    public void refreshAll() {
        footballManager.tick();

        for (TvEntry entry : tvs.values()) {
            World world = Bukkit.getWorld(entry.world);
            if (world == null) continue;
            Location loc = new Location(world, entry.x, entry.y, entry.z);

            Bukkit.getRegionScheduler().execute(plugin, loc, () -> {
                Entity display = findDisplayEntity(entry);
                if (display instanceof TextDisplay textDisplay) {
                    refreshOne(entry, textDisplay);
                }
            });
        }
    }

    private void refreshOne(TvEntry entry, TextDisplay display) {
        String content = switch (entry.channel) {
            case "football" -> buildFootballContent();
            default -> buildMarketContent();
        };
        display.setText(ChatColor.translateAlternateColorCodes('&', content));
    }

    private String buildMarketContent() {
        StringBuilder sb = new StringBuilder();
        sb.append("&6&l📺 PAPAN HARGA SAHAM\n");
        for (MarketManager.StockData stock : marketManager.getStocks()) {
            String spark = MarketManager.buildSparkline(stock);
            String trend = stock.lastChangePercent > 0 ? "&a▲"
                    : stock.lastChangePercent < 0 ? "&c▼" : "&7=";
            sb.append("&7").append(stock.name).append(": &e$")
                    .append(String.format("%.0f", stock.price))
                    .append(" ").append(trend).append(" ").append(spark).append("\n");
        }
        return sb.toString().stripTrailing();
    }

    private String buildFootballContent() {
        FootballManager.Match match = footballManager.getCurrentMatch();
        String status = match.finished ? "&cFT" : "&a" + match.minute + "'";
        return "&6&l⚽ SIARAN BOLA\n"
                + "&f" + match.homeTeam + " &e" + match.homeScore + " - " + match.awayScore + " &f" + match.awayTeam + "\n"
                + status;
    }

    /**
     * 1 entry TV yang keregister. Field public sengaja, dipakai internal
     * doang antara manager & listener/command di package yang sama grup.
     */
    public static class TvEntry {
        public final int id;
        public final String world;
        public final int x, y, z;
        public String channel;
        public UUID entityUuid;

        public TvEntry(int id, String world, int x, int y, int z, String channel, UUID entityUuid) {
            this.id = id;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.channel = channel;
            this.entityUuid = entityUuid;
        }
    }
}
