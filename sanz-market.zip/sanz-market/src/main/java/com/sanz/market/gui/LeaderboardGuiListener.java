package com.sanz.market.gui;

import com.sanz.market.managers.MarketManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.Map;

/**
 * GUI top 20 untung/rugi trader market.
 */
public class LeaderboardGuiListener implements Listener {

    public static void open(Player player, MarketManager marketManager, boolean profitMode) {
        int size = marketManager.leaderboardSizeConfig();
        List<Map.Entry<String, Double>> entries = marketManager.getLeaderboard(profitMode, size);

        LeaderboardGuiHolder holder = new LeaderboardGuiHolder();
        String title = profitMode ? "&a&lTOP " + size + " UNTUNG MARKET" : "&c&lTOP " + size + " RUGI MARKET";
        Inventory inv = Bukkit.createInventory(holder, 54, ChatColor.translateAlternateColorCodes('&', title));
        holder.setInventory(inv);

        ItemStack border = GuiItemUtil.named(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 54; i++) inv.setItem(i, border);

        if (entries.isEmpty()) {
            inv.setItem(22, GuiItemUtil.named(Material.PAPER, "&7Belum ada data trading.", null));
        } else {
            int slot = 0;
            for (Map.Entry<String, Double> entry : entries) {
                if (slot >= 45) break;
                String sign = entry.getValue() >= 0 ? "&a+$" : "&c-$";
                ItemStack head = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta meta = (SkullMeta) head.getItemMeta();
                if (meta != null) {
                    meta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getKey()));
                    meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                            "&e#" + (slot + 1) + " &f" + entry.getKey()));
                    meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',
                            "&7Profit: " + sign + String.format("%.0f", Math.abs(entry.getValue())))));
                    head.setItemMeta(meta);
                }
                inv.setItem(slot, head);
                slot++;
            }
        }

        inv.setItem(49, GuiItemUtil.named(Material.BARRIER, "&c&lTutup", null));
        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof LeaderboardGuiHolder)) return;
        event.setCancelled(true);

        if (event.getRawSlot() == 49) {
            ((Player) event.getWhoClicked()).closeInventory();
        }
    }
}
