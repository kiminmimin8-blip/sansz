package com.sanz.market.commands;

import com.sanz.market.gui.MarketGuiListener;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MarketCommand implements CommandExecutor {

    private final MarketGuiListener guiListener;

    public MarketCommand(MarketGuiListener guiListener) {
        this.guiListener = guiListener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanz.market.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk pakai command ini.");
            return true;
        }
        guiListener.open(player);
        return true;
    }
}
