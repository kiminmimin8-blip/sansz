package com.sanz.market;

import com.sanz.market.commands.MarketAdminCommand;
import com.sanz.market.commands.MarketCommand;
import com.sanz.market.commands.MarketTvCommand;
import com.sanz.market.gui.LeaderboardGuiListener;
import com.sanz.market.gui.MarketGuiListener;
import com.sanz.market.gui.TradeGuiListener;
import com.sanz.market.gui.TvChannelGuiListener;
import com.sanz.market.listeners.TvBlockListener;
import com.sanz.market.managers.FootballManager;
import com.sanz.market.managers.MarketManager;
import com.sanz.market.managers.TvManager;
import com.sanz.market.managers.VideoScreenManager;
import com.sanz.market.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * SanzMarket - market saham realistis + TV block (nonton saham/bola/dll
 * lewat TextDisplay vanilla, gak butuh plugin hologram luar).
 */
public final class SanzMarketPlugin extends JavaPlugin {

    private MarketManager marketManager;
    private TvManager tvManager;
    private VideoScreenManager videoScreenManager;

    @Override
    public void onEnable() {
        ConfigFile marketConfig = new ConfigFile(this, "market/config.yml");
        ConfigFile marketData = new ConfigFile(this, "market/data.yml");
        ConfigFile tvData = new ConfigFile(this, "market/tv-data.yml");
        ConfigFile screensData = new ConfigFile(this, "market/screens.yml");

        marketManager = new MarketManager(this, marketConfig, marketData);
        FootballManager footballManager = new FootballManager();

        Material tvBlockMaterial = Material.matchMaterial(
                marketConfig.get().getString("tv.block-material", "OBSERVER"));
        if (tvBlockMaterial == null) tvBlockMaterial = Material.OBSERVER;

        tvManager = new TvManager(this, tvData, marketManager, footballManager, tvBlockMaterial);

        videoScreenManager = new VideoScreenManager(screensData, getDataFolder());
        videoScreenManager.setPluginInstance(this);

        // ===== GUI listener =====
        MarketGuiListener marketGui = new MarketGuiListener(marketManager);
        TradeGuiListener tradeGui = new TradeGuiListener();
        TradeGuiListener.register(marketManager);
        LeaderboardGuiListener leaderboardGui = new LeaderboardGuiListener();
        TvChannelGuiListener tvChannelGui = new TvChannelGuiListener(tvManager);

        getServer().getPluginManager().registerEvents(marketGui, this);
        getServer().getPluginManager().registerEvents(tradeGui, this);
        getServer().getPluginManager().registerEvents(leaderboardGui, this);
        getServer().getPluginManager().registerEvents(tvChannelGui, this);
        getServer().getPluginManager().registerEvents(new TvBlockListener(tvManager, tvChannelGui), this);

        // ===== Command =====
        if (getCommand("market") != null) getCommand("market").setExecutor(new MarketCommand(marketGui));
        if (getCommand("marketadmin") != null) getCommand("marketadmin").setExecutor(new MarketAdminCommand(marketManager));
        if (getCommand("markettv") != null) getCommand("markettv").setExecutor(new MarketTvCommand(tvManager, videoScreenManager));

        // ===== Task berkala =====
        long marketIntervalTicks = marketConfig.get().getLong("update-interval-seconds", 300) * 20L;
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(this, task -> marketManager.tick(),
                marketIntervalTicks, marketIntervalTicks);

        long tvIntervalTicks = marketConfig.get().getLong("tv.update-interval-seconds", 15) * 20L;
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(this, task -> tvManager.refreshAll(),
                tvIntervalTicks, tvIntervalTicks);

        getLogger().info("SanzMarket enabled - " + marketManager.getStocks().size() + " saham, "
                + tvManager.getTvCount() + " TV terpasang.");
    }

    @Override
    public void onDisable() {
        if (marketManager != null) marketManager.save();
        if (tvManager != null) tvManager.save();
        if (videoScreenManager != null) {
            videoScreenManager.stopAll();
            videoScreenManager.save();
        }
    }
}
