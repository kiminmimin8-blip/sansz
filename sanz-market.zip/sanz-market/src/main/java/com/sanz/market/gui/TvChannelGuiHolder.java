package com.sanz.market.gui;

import com.sanz.market.managers.TvManager;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marker + state buat GUI pemilih channel TV. */
public class TvChannelGuiHolder implements InventoryHolder {
    private Inventory inventory;
    public final TvManager.TvEntry entry;

    public TvChannelGuiHolder(TvManager.TvEntry entry) {
        this.entry = entry;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
