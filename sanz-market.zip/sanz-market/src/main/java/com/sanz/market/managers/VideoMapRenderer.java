package com.sanz.market.managers;

import org.bukkit.entity.Player;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

/**
 * Renderer map custom buat 1 sel layar video. Nyimpen array pixel
 * (128x128, byte warna map) yang di-update tiap decode frame baru.
 * Pakai dirty-check simple (reference equality) biar gak ngulang
 * nge-draw 16384 pixel tiap render() dipanggil kalau isinya sama aja
 * kayak sebelumnya.
 */
public class VideoMapRenderer extends MapRenderer {

    private volatile byte[] pixels = new byte[128 * 128];
    private byte[] lastRendered = null;

    public VideoMapRenderer() {
        super(false); // non-contextual: 1 gambar yang sama buat semua viewer
    }

    public void setPixels(byte[] newPixels) {
        this.pixels = newPixels;
    }

    @Override
    public void render(MapView map, MapCanvas canvas, Player player) {
        byte[] current = pixels;
        if (current == lastRendered) return; // belum ada frame baru, skip

        for (int y = 0; y < 128; y++) {
            for (int x = 0; x < 128; x++) {
                canvas.setPixel(x, y, current[y * 128 + x]);
            }
        }
        lastRendered = current;
    }
}
