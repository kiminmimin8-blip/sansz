package com.sanz.market.gui;

import com.sanz.market.managers.MarketManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI utama /market: 54 slot, border rapi, saham ditaruh di slot-slot
 * yang udah ditentuin, tombol leaderboard & tutup.
 */
public class MarketGuiListener implements Listener {

    private static final int[] STOCK_SLOTS = {19, 21, 23, 25, 28, 30, 32, 34};

    private final MarketManager marketManager;

    public MarketGuiListener(MarketManager marketManager) {
        this.marketManager = marketManager;
    }

    public void open(Player player) {
        MarketGuiHolder holder = new MarketGuiHolder();
        Inventory inv = Bukkit.createInventory(holder, 54,
                ChatColor.translateAlternateColorCodes('&', "&8&lPASAR SAHAM &7- SanzMarket"));
        holder.setInventory(inv);

        ItemStack border = GuiItemUtil.named(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 54; i++) inv.setItem(i, border);

        List<MarketManager.StockData> stocks = marketManager.getStocks();
        int intervalMinutes = Math.max(1, marketManager.getUpdateIntervalSeconds() / 60);
        inv.setItem(4, GuiItemUtil.named(Material.BOOK, "&6&lInfo Pasar", List.of(
                "&7Total saham terdaftar: &e" + stocks.size(),
                "&7Update harga tiap &e" + intervalMinutes + " menit&7 sekali",
                "&7Klik saham buat beli/jual")));

        boolean isAdmin = player.hasPermission("sanz.market.admin");
        if (isAdmin) {
            inv.setItem(8, GuiItemUtil.named(Material.COMMAND_BLOCK, "&c&lAdmin Commands", List.of(
                    "&e/marketadmin setprice <saham> <harga>",
                    "&e/marketadmin addstock <nama> <hargaawal>",
                    "&e/marketadmin removestock <saham>",
                    "&e/marketadmin resethistory <saham>",
                    "&e/marketadmin info",
                    "&e/markettv give <player>")));
        }

        int i = 0;
        for (MarketManager.StockData stock : stocks) {
            if (i >= STOCK_SLOTS.length) break; // GUI cuma muat 8 saham
            int slot = STOCK_SLOTS[i++];

            String trend = stock.lastChangePercent > 0 ? "&a▲ Naik"
                    : stock.lastChangePercent < 0 ? "&c▼ Turun" : "&7= Stabil";
            int owned = marketManager.getHolding(player.getUniqueId(), stock.name);

            inv.setItem(slot, GuiItemUtil.named(stock.icon, "&a&l" + stock.name, List.of(
                    "&7Harga: &e$" + String.format("%.0f", stock.price) + "/lot",
                    "&7Milik kamu: &b" + owned + " lot",
                    "&7Trend: " + trend,
                    "",
                    "&aKlik Kiri &7-> &2BELI",
                    "&cKlik Kanan &7-> &4JUAL")));
            holder.slotToStock.put(slot, stock.name);
        }

        inv.setItem(39, GuiItemUtil.named(Material.GOLD_INGOT, "&a&l✦ Top " + marketManager.leaderboardSizeConfig() + " Untung", List.of(
                "&7Klik buat lihat player", "&7paling cuan di market!")));
        inv.setItem(41, GuiItemUtil.named(Material.REDSTONE, "&c&l✦ Top " + marketManager.leaderboardSizeConfig() + " Rugi", List.of(
                "&7Klik buat lihat player", "&7paling boncos di market!")));
        inv.setItem(49, GuiItemUtil.named(Material.BARRIER, "&c&lTutup", null));

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MarketGuiHolder holder)) return;
        event.setCancelled(true);

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;
        ItemStack clicked = event.getInventory().getItem(slot);
        if (clicked == null || clicked.getType() == Material.AIR) return;

        Player player = (Player) event.getWhoClicked();

        if (slot == 49) {
            player.closeInventory();
            return;
        }
        if (slot == 39) {
            LeaderboardGuiListener.open(player, marketManager, true);
            return;
        }
        if (slot == 41) {
            LeaderboardGuiListener.open(player, marketManager, false);
            return;
        }

        String stockName = holder.slotToStock.get(slot);
        if (stockName == null) return;

        String action = event.getClick() == ClickType.RIGHT ? "sell" : "buy";
        TradeGuiListener.open(player, marketManager, stockName, action);
    }
}
