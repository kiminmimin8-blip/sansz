package com.sanz.market.managers;

import com.sanz.market.util.ConfigFile;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Engine market saham. Beda dari versi Skript lama, harga sekarang
 * dipengaruhi beberapa faktor sekaligus (lihat market/config.yml buat
 * penjelasan tiap faktor): random noise per-saham, momentum, mean
 * reversion, "mood" pasar bersama, dan sesekali event/berita besar.
 *
 * Saldo player ditangani lewat Vault (economy asli), bukan simulasi
 * command console, jadi kompatibel sama plugin economy apapun yang
 * support Vault (EssentialsX Eco, CMI, dll).
 */
public class MarketManager {

    private final JavaPlugin plugin;
    private final ConfigFile config;
    private final ConfigFile data;
    private final Random random = new Random();

    private final Map<String, StockData> stocks = new LinkedHashMap<>();
    private final Map<UUID, Map<String, Integer>> holdings = new LinkedHashMap<>();
    private final Map<String, Double> traderProfit = new LinkedHashMap<>();
    private double marketMood = 0.0;

    private Economy economy;

    public MarketManager(JavaPlugin plugin, ConfigFile config, ConfigFile data) {
        this.plugin = plugin;
        this.config = config;
        this.data = data;
        setupEconomy();
        load();
    }

    // ================= Setup =================

    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault gak ketemu! Fitur beli/jual saham gak akan jalan sampai Vault + plugin economy dipasang.");
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            plugin.getLogger().warning("Gak ada plugin economy yang ke-hook ke Vault! Fitur beli/jual saham gak akan jalan.");
            return false;
        }
        economy = rsp.getProvider();
        return true;
    }

    public boolean isEconomyAvailable() {
        return economy != null;
    }

    public Economy getEconomy() {
        return economy;
    }

    /**
     * Load config saham + data runtime (harga, histori, holdings, profit).
     * Dipanggil onEnable dan tiap /marketadmin reload.
     */
    public void load() {
        stocks.clear();
        ConfigurationSection stocksSection = config.get().getConfigurationSection("stocks");
        if (stocksSection != null) {
            for (String name : stocksSection.getKeys(false)) {
                ConfigurationSection s = stocksSection.getConfigurationSection(name);
                if (s == null) continue;

                double startingPrice = s.getDouble("starting-price", 100);
                double volatility = s.getDouble("volatility", 1.0);
                Material icon = Material.matchMaterial(s.getString("icon", "STONE"));
                if (icon == null) icon = Material.STONE;

                StockData stock = new StockData(name, startingPrice, startingPrice, volatility, icon);
                stocks.put(name, stock);
            }
        }

        // Timpa dengan data runtime yang udah tersimpen (harga terkini, histori, dll)
        marketMood = data.get().getDouble("market-mood", 0.0);
        ConfigurationSection savedStocks = data.get().getConfigurationSection("stocks");
        if (savedStocks != null) {
            for (String name : savedStocks.getKeys(false)) {
                StockData stock = stocks.get(name);
                if (stock == null) continue; // saham udah dihapus dari config
                ConfigurationSection s = savedStocks.getConfigurationSection(name);
                if (s == null) continue;

                stock.price = s.getDouble("price", stock.price);
                stock.basePrice = s.getDouble("baseprice", stock.basePrice);
                stock.lastChangePercent = s.getDouble("last-change", 0.0);
                stock.history.clear();
                for (double h : s.getDoubleList("history")) {
                    stock.history.add(h);
                }
            }
        }
        for (StockData stock : stocks.values()) {
            if (stock.history.isEmpty()) stock.history.add(stock.price);
        }

        holdings.clear();
        ConfigurationSection tradersSection = data.get().getConfigurationSection("traders");
        if (tradersSection != null) {
            for (String uuidStr : tradersSection.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    ConfigurationSection t = tradersSection.getConfigurationSection(uuidStr);
                    if (t == null) continue;

                    String name = t.getString("name", uuidStr);
                    traderProfit.put(name, t.getDouble("profit", 0));

                    Map<String, Integer> playerHoldings = new LinkedHashMap<>();
                    ConfigurationSection h = t.getConfigurationSection("holdings");
                    if (h != null) {
                        for (String stockName : h.getKeys(false)) {
                            playerHoldings.put(stockName, h.getInt(stockName));
                        }
                    }
                    holdings.put(uuid, playerHoldings);
                } catch (IllegalArgumentException ignored) {
                    // uuid gak valid, skip
                }
            }
        }
    }

    /**
     * Simpen semua state (harga, histori, holdings, profit) ke market/data.yml.
     */
    public void save() {
        data.get().set("market-mood", marketMood);
        for (StockData stock : stocks.values()) {
            String path = "stocks." + stock.name;
            data.get().set(path + ".price", stock.price);
            data.get().set(path + ".baseprice", stock.basePrice);
            data.get().set(path + ".last-change", stock.lastChangePercent);
            data.get().set(path + ".history", stock.history);
        }

        // Bersihin dulu section traders lama biar player yang holdingnya abis 0 gak numpuk sampah
        data.get().set("traders", null);
        for (Map.Entry<UUID, Map<String, Integer>> entry : holdings.entrySet()) {
            UUID uuid = entry.getKey();
            Player p = Bukkit.getPlayer(uuid);
            String name = p != null ? p.getName() : uuid.toString();
            String path = "traders." + uuid;
            data.get().set(path + ".name", name);
            data.get().set(path + ".profit", traderProfit.getOrDefault(name, 0.0));
            for (Map.Entry<String, Integer> h : entry.getValue().entrySet()) {
                if (h.getValue() > 0) {
                    data.get().set(path + ".holdings." + h.getKey(), h.getValue());
                }
            }
        }
        data.save();
    }

    // ================= Price engine =================

    /**
     * 1 siklus update harga buat semua saham. Dipanggil berkala
     * (market/config.yml -> update-interval-seconds).
     */
    public void tick() {
        double moodVolatility = config.get().getDouble("market-mood-volatility", 1.5);
        double momentumFactor = config.get().getDouble("momentum-factor", 0.25);
        double reversionFactor = config.get().getDouble("reversion-factor", 0.08);
        double moodSensitivity = config.get().getDouble("market-mood-sensitivity", 0.6);
        double eventChance = config.get().getDouble("event-chance-percent", 4.0);
        double eventMin = config.get().getDouble("event-min-percent", 10.0);
        double eventMax = config.get().getDouble("event-max-percent", 20.0);
        double maxProfitPercent = config.get().getDouble("max-profit-percent", 25);
        double priceFloor = config.get().getDouble("price-floor", 10);
        int historyMax = config.get().getInt("history-max", 20);
        boolean broadcastEvents = config.get().getBoolean("broadcast-market-event", true);

        // Mood pasar: random walk bersama, ditarik pelan-pelan ke 0 biar gak ngelantur selamanya
        marketMood = marketMood * 0.9 + random.nextGaussian() * moodVolatility;
        marketMood = Math.max(-5.0, Math.min(5.0, marketMood));

        for (StockData stock : stocks.values()) {
            double noise = random.nextGaussian() * stock.volatility;
            double momentum = stock.lastChangePercent * momentumFactor;
            double distanceFromBase = (stock.basePrice - stock.price) / stock.basePrice * 100.0;
            double reversion = distanceFromBase * reversionFactor;
            double moodEffect = marketMood * moodSensitivity;

            double changePercent = noise + momentum + reversion + moodEffect;

            boolean isEvent = random.nextDouble() * 100.0 < eventChance;
            if (isEvent) {
                double magnitude = eventMin + random.nextDouble() * (eventMax - eventMin);
                boolean positive = random.nextBoolean();
                double shock = positive ? magnitude : -magnitude;
                changePercent += shock;

                if (broadcastEvents) {
                    String verb = positive ? "&a&lMELONJAK" : "&c&lANJLOK";
                    Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&',
                            "&8[&6Market&8] &7Berita: saham &f" + stock.name + " &7" + verb
                                    + " &7sebesar &e" + String.format("%.1f", Math.abs(shock)) + "%&7!"));
                }
            }

            double ceiling = stock.basePrice * (1 + maxProfitPercent / 100.0);
            double newPrice = stock.price * (1 + changePercent / 100.0);
            newPrice = Math.min(newPrice, ceiling);
            newPrice = Math.max(newPrice, priceFloor);

            stock.lastChangePercent = changePercent;
            stock.price = Math.round(newPrice * 100.0) / 100.0;

            stock.history.add(stock.price);
            while (stock.history.size() > historyMax) {
                stock.history.remove(0);
            }
        }

        save();
    }

    // ================= Trading =================

    public enum TradeResult {
        SUCCESS, STOCK_NOT_FOUND, BELOW_MIN, ABOVE_MAX, INSUFFICIENT_BALANCE, INSUFFICIENT_HOLDINGS, NO_ECONOMY
    }

    public TradeResult buy(Player player, String stockName, int amount) {
        if (!isEconomyAvailable()) return TradeResult.NO_ECONOMY;

        StockData stock = stocks.get(stockName);
        if (stock == null) return TradeResult.STOCK_NOT_FOUND;

        double total = stock.price * amount;
        double minTx = config.get().getDouble("min-transaction", 10000);
        double maxTx = config.get().getDouble("max-transaction", 100000000);
        if (total < minTx) return TradeResult.BELOW_MIN;
        if (total > maxTx) return TradeResult.ABOVE_MAX;

        if (!economy.has(player, total)) return TradeResult.INSUFFICIENT_BALANCE;

        economy.withdrawPlayer(player, total);
        addHolding(player.getUniqueId(), stockName, amount);
        addProfit(player.getName(), -total);
        return TradeResult.SUCCESS;
    }

    public TradeResult sell(Player player, String stockName, int amount) {
        if (!isEconomyAvailable()) return TradeResult.NO_ECONOMY;

        StockData stock = stocks.get(stockName);
        if (stock == null) return TradeResult.STOCK_NOT_FOUND;

        int owned = getHolding(player.getUniqueId(), stockName);
        if (owned < amount) return TradeResult.INSUFFICIENT_HOLDINGS;

        double total = stock.price * amount;
        economy.depositPlayer(player, total);
        addHolding(player.getUniqueId(), stockName, -amount);
        addProfit(player.getName(), total);
        return TradeResult.SUCCESS;
    }

    private void addHolding(UUID uuid, String stockName, int delta) {
        Map<String, Integer> playerHoldings = holdings.computeIfAbsent(uuid, k -> new LinkedHashMap<>());
        int current = playerHoldings.getOrDefault(stockName, 0);
        playerHoldings.put(stockName, Math.max(0, current + delta));
    }

    private void addProfit(String playerName, double delta) {
        traderProfit.merge(playerName, delta, Double::sum);
    }

    public int getHolding(UUID uuid, String stockName) {
        return holdings.getOrDefault(uuid, Map.of()).getOrDefault(stockName, 0);
    }

    // ================= Getter / query =================

    public List<StockData> getStocks() {
        return new ArrayList<>(stocks.values());
    }

    public StockData getStock(String name) {
        return stocks.get(name);
    }

    public List<Map.Entry<String, Double>> getLeaderboard(boolean profitDescending, int limit) {
        return traderProfit.entrySet().stream()
                .sorted((a, b) -> profitDescending
                        ? Double.compare(b.getValue(), a.getValue())
                        : Double.compare(a.getValue(), b.getValue()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public int leaderboardSizeConfig() {
        return config.get().getInt("leaderboard-size", 20);
    }

    public int getUpdateIntervalSeconds() {
        return config.get().getInt("update-interval-seconds", 300);
    }

    // ================= Admin operations =================

    public boolean setPrice(String stockName, double price) {
        StockData stock = stocks.get(stockName);
        if (stock == null) return false;
        stock.price = price;
        stock.history.add(price);
        save();
        return true;
    }

    public boolean addStock(String name, double startingPrice) {
        if (stocks.containsKey(name)) return false;
        StockData stock = new StockData(name, startingPrice, startingPrice, 1.0, Material.STONE);
        stocks.put(name, stock);

        config.get().set("stocks." + name + ".starting-price", startingPrice);
        config.get().set("stocks." + name + ".volatility", 1.0);
        config.get().set("stocks." + name + ".icon", "STONE");
        config.save();
        save();
        return true;
    }

    public boolean removeStock(String name) {
        if (!stocks.containsKey(name)) return false;
        stocks.remove(name);
        config.get().set("stocks." + name, null);
        config.save();
        for (Map<String, Integer> h : holdings.values()) {
            h.remove(name);
        }
        save();
        return true;
    }

    public boolean resetHistory(String name) {
        StockData stock = stocks.get(name);
        if (stock == null) return false;
        stock.history.clear();
        stock.history.add(stock.price);
        save();
        return true;
    }

    public void reload() {
        config.reload();
        load();
    }

    // ================= Sparkline =================

    private static final String[] BARS = {"▁", "▂", "▃", "▄", "▅", "▆", "▇", "█"};

    /**
     * Grafik mini pakai karakter blok, warna ijo/merah/kuning nyesuain
     * naik/turun tiap titik histori. Contoh: ▁▂▄▅▇█▆▃
     */
    public static String buildSparkline(StockData stock) {
        List<Double> history = stock.history;
        if (history.size() < 2) return "&7▬▬▬▬▬▬▬▬";

        double min = history.get(0), max = history.get(0);
        for (double v : history) {
            min = Math.min(min, v);
            max = Math.max(max, v);
        }
        double range = Math.max(1.0, max - min);

        StringBuilder result = new StringBuilder();
        double prev = history.get(0);
        for (double val : history) {
            double normalized = ((val - min) / range) * 7;
            int idx = (int) Math.round(normalized);
            idx = Math.max(0, Math.min(7, idx));

            String color = val > prev ? "&a" : val < prev ? "&c" : "&e";
            result.append(color).append(BARS[idx]);
            prev = val;
        }
        return result.toString();
    }

    /**
     * Data 1 saham. Field public sengaja (dipakai internal doang di
     * package managers/gui, biar gak perlu getter/setter bertele-tele).
     */
    public static class StockData {
        public final String name;
        public double price;
        public double basePrice;
        public double volatility;
        public double lastChangePercent = 0.0;
        public final Material icon;
        public final List<Double> history = new ArrayList<>();

        public StockData(String name, double price, double basePrice, double volatility, Material icon) {
            this.name = name;
            this.price = price;
            this.basePrice = basePrice;
            this.volatility = volatility;
            this.icon = icon;
        }
    }
}
