package com.sanz.market.managers;

import com.sanz.market.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapView;
import org.bukkit.util.RayTraceResult;
import org.jcodec.api.FrameGrab;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.common.model.Picture;
import org.jcodec.scale.AWTUtil;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Layar video gede dari susunan grid ItemFrame + FILLED_MAP. Video di
 * decode pakai JCodec (pure Java, gak butuh FFmpeg terinstall) di
 * thread async, terus tiap sel grid nampilin bagiannya masing-masing
 * lewat VideoMapRenderer.
 *
 * Setup: admin pos1/pos2 di 2 item frame pojok (kiri-atas & kanan-bawah)
 * yang udah ditaro manual di dunia (nempel tembok, ngadep 1 arah yang
 * sama), terus /markettv screen create bikin grid-nya otomatis.
 */
public class VideoScreenManager {

    private static final int CELL_SIZE = 128; // resolusi 1 map Minecraft

    private final ConfigFile screensData;
    private final File videosFolder;
    private org.bukkit.plugin.Plugin pluginInstance;

    private final Map<String, Screen> screens = new LinkedHashMap<>();
    private final Map<UUID, ItemFrame> pos1Selection = new LinkedHashMap<>();
    private final Map<UUID, ItemFrame> pos2Selection = new LinkedHashMap<>();
    private final Map<String, Playback> activePlaybacks = new LinkedHashMap<>();

    public VideoScreenManager(ConfigFile screensData, File pluginDataFolder) {
        this.screensData = screensData;
        this.videosFolder = new File(pluginDataFolder, "videos");
        if (!videosFolder.exists()) videosFolder.mkdirs();
        load();
    }

    public void setPluginInstance(org.bukkit.plugin.Plugin plugin) {
        this.pluginInstance = plugin;
    }

    // ================= Selection (pos1/pos2) =================

    public String setPos(Player admin, int index) {
        RayTraceResult result = admin.getWorld().rayTraceEntities(
                admin.getEyeLocation(), admin.getEyeLocation().getDirection(), 10,
                entity -> entity instanceof ItemFrame);
        if (result == null || !(result.getHitEntity() instanceof ItemFrame frame)) {
            return "Gak ada item frame yang kamu lihat (maks jarak 10 block).";
        }

        if (index == 1) pos1Selection.put(admin.getUniqueId(), frame);
        else pos2Selection.put(admin.getUniqueId(), frame);
        return null;
    }

    // ================= Screen creation =================

    public String createScreen(Player admin, String name) {
        if (screens.containsKey(name)) return "Screen '" + name + "' udah ada.";

        ItemFrame f1 = pos1Selection.get(admin.getUniqueId());
        ItemFrame f2 = pos2Selection.get(admin.getUniqueId());
        if (f1 == null || f2 == null) return "Set pos1 & pos2 dulu (lihat ke item frame pojok, /markettv screen pos1 / pos2).";
        if (!f1.isValid() || !f2.isValid()) return "Item frame pos1/pos2 udah gak valid, set ulang.";
        if (!f1.getWorld().equals(f2.getWorld())) return "Pos1 & pos2 harus di world yang sama.";

        BlockFace facing = f1.getFacing();
        if (facing != f2.getFacing()) return "Pos1 & pos2 harus ngadep arah yang sama.";
        if (facing != BlockFace.NORTH && facing != BlockFace.SOUTH
                && facing != BlockFace.EAST && facing != BlockFace.WEST) {
            return "Cuma support item frame yang nempel tembok (utara/selatan/timur/barat), bukan lantai/langit-langit.";
        }

        boolean horizontalIsX = (facing == BlockFace.NORTH || facing == BlockFace.SOUTH);
        World world = f1.getWorld();

        double hMin = Math.min(horizontalIsX ? f1.getLocation().getX() : f1.getLocation().getZ(),
                horizontalIsX ? f2.getLocation().getX() : f2.getLocation().getZ());
        double hMax = Math.max(horizontalIsX ? f1.getLocation().getX() : f1.getLocation().getZ(),
                horizontalIsX ? f2.getLocation().getX() : f2.getLocation().getZ());
        double vMin = Math.min(f1.getLocation().getY(), f2.getLocation().getY());
        double vMax = Math.max(f1.getLocation().getY(), f2.getLocation().getY());

        List<ItemFrame> matched = new ArrayList<>();
        TreeSet<Double> hValues = new TreeSet<>();
        TreeSet<Double> vValues = new TreeSet<>();

        for (ItemFrame frame : world.getEntitiesByClass(ItemFrame.class)) {
            if (frame.getFacing() != facing) continue;
            double h = horizontalIsX ? frame.getLocation().getX() : frame.getLocation().getZ();
            double v = frame.getLocation().getY();
            if (h < hMin - 0.01 || h > hMax + 0.01 || v < vMin - 0.01 || v > vMax + 0.01) continue;

            matched.add(frame);
            hValues.add(round(h));
            vValues.add(round(v));
        }

        int cols = hValues.size();
        int rows = vValues.size();
        if (cols == 0 || rows == 0) return "Gak nemu item frame di area itu.";
        if (matched.size() != cols * rows) {
            return "Grid gak lengkap: nemu " + matched.size() + " item frame, tapi butuh " + (cols * rows)
                    + " (" + cols + "x" + rows + "). Pastiin gak ada slot yang bolong.";
        }
        if ((long) cols * rows > 64) {
            return "Grid kegedean (" + cols + "x" + rows + " = " + (cols * rows) + " map). Maks 64 map per screen.";
        }

        List<Double> hSorted = new ArrayList<>(hValues); // urutan kiri->kanan otomatis (TreeSet ascending)
        List<Double> vSorted = new ArrayList<>(vValues); // ascending = bawah->atas, kita balik jadi atas->bawah

        UUID[][] frameGrid = new UUID[rows][cols];
        VideoMapRenderer[][] rendererGrid = new VideoMapRenderer[rows][cols];

        for (ItemFrame frame : matched) {
            double h = round(horizontalIsX ? frame.getLocation().getX() : frame.getLocation().getZ());
            double v = round(frame.getLocation().getY());
            int col = hSorted.indexOf(h);
            int row = (rows - 1) - vSorted.indexOf(v); // baris 0 = paling atas

            VideoMapRenderer renderer = bindMap(frame);
            frameGrid[row][col] = frame.getUniqueId();
            rendererGrid[row][col] = renderer;
        }

        Screen screen = new Screen(name, world.getName(), cols, rows, frameGrid, rendererGrid);
        screens.put(name, screen);
        save();

        pos1Selection.remove(admin.getUniqueId());
        pos2Selection.remove(admin.getUniqueId());
        return null;
    }

    private VideoMapRenderer bindMap(ItemFrame frame) {
        MapView view = Bukkit.createMap(frame.getWorld());
        for (var r : new ArrayList<>(view.getRenderers())) view.removeRenderer(r);
        VideoMapRenderer renderer = new VideoMapRenderer();
        view.addRenderer(renderer);
        view.setTrackingPosition(false);
        view.setUnlimitedTracking(false);

        ItemStack mapItem = new ItemStack(Material.FILLED_MAP);
        MapMeta meta = (MapMeta) mapItem.getItemMeta();
        if (meta != null) {
            meta.setMapView(view);
            mapItem.setItemMeta(meta);
        }
        frame.setItem(mapItem);
        return renderer;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    // ================= Persistence =================

    private void load() {
        screens.clear();
        ConfigurationSection section = screensData.get().getConfigurationSection("screens");
        if (section == null) return;

        for (String name : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(name);
            if (s == null) continue;

            String worldName = s.getString("world");
            World world = Bukkit.getWorld(worldName);
            if (world == null) continue;

            int cols = s.getInt("cols");
            int rows = s.getInt("rows");
            UUID[][] frameGrid = new UUID[rows][cols];
            VideoMapRenderer[][] rendererGrid = new VideoMapRenderer[rows][cols];

            ConfigurationSection framesSection = s.getConfigurationSection("frames");
            boolean valid = true;
            if (framesSection != null) {
                for (int row = 0; row < rows; row++) {
                    for (int col = 0; col < cols; col++) {
                        String uuidStr = framesSection.getString(row + "," + col);
                        if (uuidStr == null) { valid = false; continue; }
                        UUID uuid = UUID.fromString(uuidStr);
                        frameGrid[row][col] = uuid;

                        if (Bukkit.getEntity(uuid) instanceof ItemFrame frame) {
                            rendererGrid[row][col] = bindMap(frame);
                        } else {
                            valid = false;
                        }
                    }
                }
            }

            if (valid) {
                screens.put(name, new Screen(name, worldName, cols, rows, frameGrid, rendererGrid));
            }
        }
    }

    public void save() {
        screensData.get().set("screens", null);
        for (Screen screen : screens.values()) {
            String path = "screens." + screen.name;
            screensData.get().set(path + ".world", screen.world);
            screensData.get().set(path + ".cols", screen.cols);
            screensData.get().set(path + ".rows", screen.rows);
            for (int row = 0; row < screen.rows; row++) {
                for (int col = 0; col < screen.cols; col++) {
                    UUID uuid = screen.frameGrid[row][col];
                    if (uuid != null) {
                        screensData.get().set(path + ".frames." + row + "," + col, uuid.toString());
                    }
                }
            }
        }
        screensData.save();
    }

    // ================= Getters =================

    public Screen getScreen(String name) {
        return screens.get(name);
    }

    public List<String> listScreens() {
        return new ArrayList<>(screens.keySet());
    }

    public File getVideosFolder() {
        return videosFolder;
    }

    public List<String> listVideos() {
        File[] files = videosFolder.listFiles((dir, filename) -> filename.toLowerCase().endsWith(".mp4"));
        List<String> names = new ArrayList<>();
        if (files != null) {
            for (File f : files) names.add(f.getName());
        }
        return names;
    }

    // ================= Playback =================

    public String play(String screenName, String videoFileName, int fps) {
        Screen screen = screens.get(screenName);
        if (screen == null) return "Screen '" + screenName + "' gak ditemukan.";

        File videoFile = new File(videosFolder, videoFileName);
        if (!videoFile.exists()) return "File video '" + videoFileName + "' gak ketemu di plugins/SanzMarket/videos/.";

        stop(screenName); // stop playback lama kalau ada

        Playback playback = new Playback();
        activePlaybacks.put(screenName, playback);

        int targetWidth = screen.cols * CELL_SIZE;
        int targetHeight = screen.rows * CELL_SIZE;
        long delayMs = Math.max(50, 1000 / Math.max(1, fps));

        Bukkit.getAsyncScheduler().runNow(pluginInstance, scheduledTask ->
                runPlaybackLoop(screen, videoFile, playback, targetWidth, targetHeight, delayMs));

        return null;
    }

    public boolean stop(String screenName) {
        Playback playback = activePlaybacks.remove(screenName);
        if (playback == null) return false;
        playback.running.set(false);
        return true;
    }

    public boolean isPlaying(String screenName) {
        return activePlaybacks.containsKey(screenName);
    }

    public void stopAll() {
        for (String screenName : new ArrayList<>(activePlaybacks.keySet())) {
            stop(screenName);
        }
    }

    private void runPlaybackLoop(Screen screen, File videoFile, Playback playback,
                                  int targetWidth, int targetHeight, long delayMs) {
        SeekableByteChannel channel = null;
        try {
            channel = NIOUtils.readableChannel(videoFile);
            FrameGrab grab = FrameGrab.createFrameGrab(channel);

            while (playback.running.get()) {
                Picture nativePicture = grab.getNativeFrame();
                if (nativePicture == null) {
                    // Video abis, loop dari awal lagi
                    grab = FrameGrab.createFrameGrab(NIOUtils.readableChannel(videoFile));
                    continue;
                }

                BufferedImage frame = AWTUtil.toBufferedImage(nativePicture);
                BufferedImage scaled = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
                Graphics2D g2d = scaled.createGraphics();
                g2d.drawImage(frame, 0, 0, targetWidth, targetHeight, null);
                g2d.dispose();

                for (int row = 0; row < screen.rows; row++) {
                    for (int col = 0; col < screen.cols; col++) {
                        VideoMapRenderer renderer = screen.rendererGrid[row][col];
                        if (renderer == null) continue;
                        renderer.setPixels(extractCellPixels(scaled, col, row));
                    }
                }

                Thread.sleep(delayMs);
            }
        } catch (InterruptedException ignored) {
            // stop() dipanggil, keluar loop dengan tenang
        } catch (Exception e) {
            Bukkit.getLogger().warning("[SanzMarket] Error playback video '" + videoFile.getName() + "': " + e.getMessage());
        } finally {
            NIOUtils.closeQuietly(channel);
        }
    }

    private byte[] extractCellPixels(BufferedImage scaled, int col, int row) {
        byte[] pixels = new byte[CELL_SIZE * CELL_SIZE];
        int offsetX = col * CELL_SIZE;
        int offsetY = row * CELL_SIZE;
        for (int y = 0; y < CELL_SIZE; y++) {
            for (int x = 0; x < CELL_SIZE; x++) {
                int rgb = scaled.getRGB(offsetX + x, offsetY + y);
                int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
                pixels[y * CELL_SIZE + x] = org.bukkit.map.MapPalette.matchColor(new java.awt.Color(r, g, b));
            }
        }
        return pixels;
    }

    // ================= Data classes =================

    public static class Screen {
        public final String name;
        public final String world;
        public final int cols, rows;
        public final UUID[][] frameGrid;
        public final VideoMapRenderer[][] rendererGrid;

        public Screen(String name, String world, int cols, int rows, UUID[][] frameGrid, VideoMapRenderer[][] rendererGrid) {
            this.name = name;
            this.world = world;
            this.cols = cols;
            this.rows = rows;
            this.frameGrid = frameGrid;
            this.rendererGrid = rendererGrid;
        }
    }

    private static class Playback {
        final AtomicBoolean running = new AtomicBoolean(true);
    }
}
