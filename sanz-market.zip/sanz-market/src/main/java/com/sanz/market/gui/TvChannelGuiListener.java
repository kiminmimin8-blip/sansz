package com.sanz.market.gui;

import com.sanz.market.managers.TvManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.List;

/**
 * GUI kecil (1 baris) buat milih channel yang lagi ditonton di TV
 * block: Saham atau Sepak Bola. Gampang nambah channel baru ke depannya,
 * tinggal tambah 1 slot lagi di sini + 1 case baru di TvManager.
 */
public class TvChannelGuiListener implements Listener {

    private final TvManager tvManager;

    public TvChannelGuiListener(TvManager tvManager) {
        this.tvManager = tvManager;
    }

    public void open(Player player, TvManager.TvEntry entry) {
        TvChannelGuiHolder holder = new TvChannelGuiHolder(entry);
        Inventory inv = Bukkit.createInventory(holder, 9,
                ChatColor.translateAlternateColorCodes('&', "&8&lPilih Channel TV"));
        holder.setInventory(inv);

        inv.setItem(3, GuiItemUtil.named(Material.GOLD_INGOT, "&6&l📈 Saham", List.of(
                "&7Nonton papan harga saham live", "",
                entry.channel.equals("market") ? "&a&lLagi ditonton" : "&7Klik buat ganti")));
        inv.setItem(5, GuiItemUtil.named(Material.LEATHER, "&a&l⚽ Sepak Bola", List.of(
                "&7Nonton siaran pertandingan simulasi", "",
                entry.channel.equals("football") ? "&a&lLagi ditonton" : "&7Klik buat ganti")));

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof TvChannelGuiHolder holder)) return;
        event.setCancelled(true);

        int slot = event.getRawSlot();
        Player player = (Player) event.getWhoClicked();

        if (slot == 3) {
            tvManager.setChannel(holder.entry, "market");
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8[&6Market&8]&7 Channel TV diganti ke &6Saham&7."));
            player.closeInventory();
        } else if (slot == 5) {
            tvManager.setChannel(holder.entry, "football");
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8[&6Market&8]&7 Channel TV diganti ke &aSepak Bola&7."));
            player.closeInventory();
        }
    }
}
