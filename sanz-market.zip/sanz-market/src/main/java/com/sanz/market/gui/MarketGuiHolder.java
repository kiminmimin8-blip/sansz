package com.sanz.market.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/**
 * Marker + state buat GUI market utama. Nyimpen mapping slot->nama
 * saham biar klik gampang dicocokin balik ke saham mana tanpa perlu
 * parsing display name (rapuh kalau ada '&' color code campur aduk).
 */
public class MarketGuiHolder implements InventoryHolder {
    private Inventory inventory;
    public final Map<Integer, String> slotToStock = new HashMap<>();

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
