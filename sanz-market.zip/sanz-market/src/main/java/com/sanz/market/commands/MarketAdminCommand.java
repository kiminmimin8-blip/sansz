package com.sanz.market.commands;

import com.sanz.market.managers.MarketManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MarketAdminCommand implements CommandExecutor {

    private final MarketManager marketManager;

    public MarketAdminCommand(MarketManager marketManager) {
        this.marketManager = marketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanz.market.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (args.length < 1) {
            sendUsage(sender);
            return true;
        }

        String action = args[0].toLowerCase();
        switch (action) {
            case "setprice":
                return setPrice(sender, args);
            case "addstock":
                return addStock(sender, args);
            case "removestock":
                return removeStock(sender, args);
            case "resethistory":
                return resetHistory(sender, args);
            case "info":
                return info(sender);
            case "reload":
                marketManager.reload();
                sender.sendMessage(prefix() + ChatColor.GREEN + "Config market di-reload.");
                return true;
            default:
                sendUsage(sender);
                return true;
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.RED + "Gunakan salah satu:");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin setprice <saham> <harga>");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin addstock <nama> <hargaawal>");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin removestock <saham>");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin resethistory <saham>");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin info");
        sender.sendMessage(ChatColor.GRAY + "/marketadmin reload");
    }

    private boolean setPrice(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(prefix() + ChatColor.RED + "Gunakan: /marketadmin setprice <saham> <harga>");
            return true;
        }
        try {
            double price = Double.parseDouble(args[2]);
            boolean success = marketManager.setPrice(args[1], price);
            sender.sendMessage(success
                    ? prefix() + ChatColor.GREEN + "Harga " + args[1] + " diubah ke $" + price
                    : prefix() + ChatColor.RED + "Saham " + args[1] + " tidak ditemukan.");
        } catch (NumberFormatException e) {
            sender.sendMessage(prefix() + ChatColor.RED + "Harga harus berupa angka.");
        }
        return true;
    }

    private boolean addStock(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(prefix() + ChatColor.RED + "Gunakan: /marketadmin addstock <nama> <hargaawal>");
            return true;
        }
        try {
            double price = Double.parseDouble(args[2]);
            boolean success = marketManager.addStock(args[1], price);
            if (success) {
                sender.sendMessage(prefix() + ChatColor.GREEN + "Saham " + args[1] + " ditambahkan seharga $" + price + "!");
            } else {
                sender.sendMessage(prefix() + ChatColor.RED + "Saham " + args[1] + " sudah ada!");
            }
        } catch (NumberFormatException e) {
            sender.sendMessage(prefix() + ChatColor.RED + "Harga awal harus berupa angka.");
        }
        return true;
    }

    private boolean removeStock(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(prefix() + ChatColor.RED + "Gunakan: /marketadmin removestock <saham>");
            return true;
        }
        boolean success = marketManager.removeStock(args[1]);
        sender.sendMessage(success
                ? prefix() + ChatColor.GREEN + "Saham " + args[1] + " dihapus."
                : prefix() + ChatColor.RED + "Saham " + args[1] + " tidak ditemukan.");
        return true;
    }

    private boolean resetHistory(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(prefix() + ChatColor.RED + "Gunakan: /marketadmin resethistory <saham>");
            return true;
        }
        boolean success = marketManager.resetHistory(args[1]);
        sender.sendMessage(success
                ? prefix() + ChatColor.GREEN + "History " + args[1] + " direset."
                : prefix() + ChatColor.RED + "Saham " + args[1] + " tidak ditemukan.");
        return true;
    }

    private boolean info(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "== Info Semua Saham ==");
        for (MarketManager.StockData stock : marketManager.getStocks()) {
            sender.sendMessage(ChatColor.GRAY + "- " + ChatColor.WHITE + stock.name + ChatColor.GRAY
                    + ": harga " + ChatColor.YELLOW + "$" + String.format("%.0f", stock.price)
                    + ChatColor.GRAY + " | base " + ChatColor.YELLOW + "$" + String.format("%.0f", stock.basePrice)
                    + ChatColor.GRAY + " | volatilitas " + ChatColor.YELLOW + stock.volatility);
        }
        return true;
    }

    private String prefix() {
        return ChatColor.translateAlternateColorCodes('&', "&8[&6Market&8]&7 ");
    }
}
