package com.sanz.market.listeners;

import com.sanz.market.gui.TvChannelGuiListener;
import com.sanz.market.managers.TvManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;

/**
 * Nangkep place/break/klik-kanan block TV. Deteksi item TV lewat
 * PersistentDataContainer (TvManager.isTvItem), bukan display name.
 */
public class TvBlockListener implements Listener {

    private final TvManager tvManager;
    private final TvChannelGuiListener channelGui;

    public TvBlockListener(TvManager tvManager, TvChannelGuiListener channelGui) {
        this.tvManager = tvManager;
        this.channelGui = channelGui;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        if (!tvManager.isTvItem(event.getItemInHand())) return;
        tvManager.placeTv(event.getBlockPlaced());
        event.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8[&6Market&8]&7 TV berhasil dipasang! Klik kanan buat ganti channel."));
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        TvManager.TvEntry entry = tvManager.getTvAt(event.getBlock());
        if (entry == null) return;

        event.setDropItems(false);
        tvManager.removeTv(entry);
        event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), tvManager.createTvItem());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;

        TvManager.TvEntry entry = tvManager.getTvAt(event.getClickedBlock());
        if (entry == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        channelGui.open(player, entry);
    }
}
